package com.catraca_gpio.enums;

/**
 * Para chamar esses enums vamos usar 
 * Comportamento.enum_exemplo.ordinal();
 * @author samuel
 *
 */
public enum Comportamento {

	NENHUM_LIVRE, DIREITA_LIVRE, ESQUERDA_LIVRE;
	
}
                                                      