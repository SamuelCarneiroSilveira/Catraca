package com.catraca_gpio.eventos;
import java.io.IOException;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;
import com.catraca_gpio.controller.GateController;
import com.catraca_gpio.enums.Comportamento;
import com.catraca_gpio.enums.Giro;

public class TesteMainEnums {

	public static void main(String[] args) throws Exception {

		GateController gate;
		Scanner input = new Scanner(System.in);
		Comportamento comportamento = null;
		Giro giro = null;

		int temporaria = 0;
		int temporariaInterna = 0;
		boolean exit = false;

		// Sequência de inicio 
		
		while (!exit) {

			menuInicialComportamento();
			temporaria = input.nextInt();

			switch (temporaria) {
			case 1:
				comportamento = Comportamento.NENHUM_LIVRE;
				exit = true;
				break;
			case 2:
				comportamento = Comportamento.DIREITA_LIVRE;
				exit = true;
				break;
			case 3:
				comportamento = Comportamento.ESQUERDA_LIVRE;
				exit = true;
				break;
			default:
				System.out.println("Escolha uma opção válida");
				TimeUnit.SECONDS.sleep(1);
				break;
			}
			limpaTela();
		}

		temporaria = 0;
		exit = false;

		while (!exit) {

			menuInicialGiro();
			temporaria = input.nextInt();

			switch (temporaria) {
			case 1:
				giro = Giro.AMBOS;
				exit = true;
				break;
			case 2:
				giro = Giro.DIREITA;
				exit = true;
				break;
			case 3:
				giro = Giro.ESQUERDA;
				exit = true;
				break;
			default:
				System.out.println("Escolha uma opção válida");
				TimeUnit.SECONDS.sleep(1);
				break;
			}
			limpaTela();
		}

		temporaria = 0;
		exit = false; 

		gate = new GateController(comportamento, giro);
		
		// Loop principal
		
		while (temporaria != 7) {
			
			exit = false;
			temporariaInterna = 0;
			
			menuPrincipal();
			temporaria = input.nextInt();

			limpaTela();
			
			switch (temporaria) {

			case 1:
				System.out.println("Modo giro");
				if(gate.Giro()){
					System.out.println("Giro completo!");
					TimeUnit.SECONDS.sleep(1);
				}else {
					System.out.println("Giro falhou!");
					TimeUnit.SECONDS.sleep(1);
				}
				break;
			case 2:
				System.out.println("Modo ticket negado");				
				for(int i = 0; i <=1 ; i++) {
					gate.TicketNegado(); // roda 2x
					TimeUnit.SECONDS.sleep(1); 
				}
				TimeUnit.SECONDS.sleep(1);
				break;
			case 3:
				System.out.println("Modo standard"); // roda 2x
				for(int i = 0; i <=1 ; i++) {
					gate.standard();					
				}
				break;
			case 4:
				System.out.println("Alterar comportamento atual");
				
				while(!exit) {
					menuAlterarComportamento();
					temporariaInterna = input.nextInt();
					limpaTela();
					
					switch(temporariaInterna) {
						case 1:
							gate.setComportamento(Comportamento.NENHUM_LIVRE);
							exit = true;
							break;
						case 2:
							gate.setComportamento(Comportamento.DIREITA_LIVRE);
							exit = true;
							break;
						case 3:
							gate.setComportamento(Comportamento.ESQUERDA_LIVRE);
							exit = true;
							break;
						default:
							System.out.println("Selecione uma opção válida");
							TimeUnit.SECONDS.sleep(1); 
							break;
					}
				}
				break;
			case 5:
				System.out.println("Alterar giro atual");
				while(!exit) {
					menuAlterarGiro();
					temporariaInterna = input.nextInt();
					limpaTela();
					
					switch(temporariaInterna) {
						case 1:
							gate.setGiro(Giro.AMBOS);
							exit = true;
							break;
						case 2:
							gate.setGiro(Giro.DIREITA);
							exit = true;
							break;
						case 3:
							gate.setGiro(Giro.ESQUERDA);
							exit = true;
							break;
						default:
							System.out.println("Selecione uma opção válida");
							TimeUnit.SECONDS.sleep(1); 
							break;
					}
				}
				exit = false;
				break;
			case 6: 
					System.out.println("Testar a Placa");
					gate.testaPlaca(); 	
				break;
			default:
				System.out.println("Informe uma opção válida");
				TimeUnit.SECONDS.sleep(1); 
				break;
			}
			limpaTela();
		}
		gate.sequenciaDeEncerramentoGpios(); // mostrar essa aqui para o wesley
		input.close();
	}
	
	/**
	 * Limpa o prompt no windows e em sistemas unix-like
	 * 
	 * @throws IOException
	 * @throws InterruptedException
	 */
	private static void limpaTela() throws IOException, InterruptedException {

		if (System.getProperty("os.name").contains("Windows"))
			new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
		else
			Runtime.getRuntime().exec("clear");
	}
	
	public static void menuInicialComportamento() {

		System.out.println("------------------||  MENU INCIAL DE COMPORTAMENTO  ||------------------");
		System.out.println("");
		System.out.println("Escolha o comportamento padrão de funcionamento");
		System.out.println("");
		System.out.println("1 - Bloqueia entradas não autorizadas para os dois lados ");
		System.out.println("2 - Bloqueia entradas não autorizadas para a esquerda");
		System.out.println("3 - Bloqueia entradas não autorizadas para a direita");

	}

	private static void menuInicialGiro() {

		System.out.println("------------------||  MENU INICIAL DE GIRO  ||------------------");
		System.out.println("");
		System.out.println("Escolha o comportamento padrão de giro");
		System.out.println("");
		System.out.println("1 - Autoriza giro para os dois lados ");
		System.out.println("2 - Autoriza giro para a direita");
		System.out.println("3 - Autoriza giro para a esquerda");

	}

	private static void menuPrincipal() {

		System.out.println("------------------||  MENU PRINCIPAL  ||------------------");
		System.out.println("");
		System.out.println("Escolha a ação a ser testada");
		System.out.println("");
		System.out.println("1 - Ticket Autorizado - giro");
		System.out.println("2 - Ticket Negado");
		System.out.println("3 - Padrão");
		System.out.println("4 - Altera padrão de funcionamento");
		System.out.println("5 - Alterar padrão de giro");
		System.out.println("6 - Testar a placa");
		System.out.println("7 - Sair");
	}
	
	private static void menuAlterarComportamento() {
		System.out.println("------------------||  MENU ALTERAR COMPORTAMENTO ||------------------");
		System.out.println("");
		System.out.println("1 - Bloqueia entradas não autorizadas para os dois lados ");
		System.out.println("2 - Bloqueia entradas não autorizadas para a esquerda");
		System.out.println("3 - Bloqueia entradas não autorizadas para a direita");
	}

	private static void menuAlterarGiro() {
		System.out.println("------------------||  MENU ALTERAR PADRÃO DE GIRO ||------------------");
		System.out.println("");
		System.out.println("1 - Autoriza giro para os dois lados ");
		System.out.println("2 - Autoriza giro para a direita");
		System.out.println("3 - Autoriza giro para a esquerda");
	}
}
