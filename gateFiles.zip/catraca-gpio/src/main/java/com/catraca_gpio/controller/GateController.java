package com.catraca_gpio.controller;

import java.util.concurrent.TimeUnit;

import com.catraca_gpio.enums.Comportamento;
import com.catraca_gpio.enums.Giro;

/**
 * Esta classe é responsável por traduzir os comandos para a classe
 * gpio.controller
 * 
 * @author Samuel C. Silveira
 *
 */
public class GateController {

	private final GpioController pictoEsquerda;
	private final GpioController pictoDireita;
	private final GpioController pictoNegado;
	private final GpioController buzzer;
	private final GpioController solenoideEsquerda;
	private final GpioController solenoideDireita;
	private final GpioController sensorEsquerda;
	private final GpioController sensorDireita;

	// Enums padrão
	private Giro giro;
	private Comportamento comportamento;

	/**
	 * Construtor, recebe os comportamentos padrões de funcionamento, e seta as
	 * gpios em seus comportamentos iniciais
	 * 
	 * @throws Exception
	 */
	public GateController(Comportamento comportamento, Giro giro) throws Exception {

		this.comportamento = comportamento;
		this.giro = giro;

		this.pictoEsquerda = new GpioController(3);
		this.pictoDireita = new GpioController(2);
		this.pictoNegado = new GpioController(10);
		this.buzzer = new GpioController(27);
		this.solenoideDireita = new GpioController(11);
		this.solenoideEsquerda = new GpioController(6);
		this.sensorEsquerda = new GpioController(4);
		this.sensorDireita = new GpioController(5);

		setarComportamentosIniciais();
	}

	/**
	 * -------------------------------------------------------------------------
	 * MÉTODOS PRIVADOS
	 * -------------------------------------------------------------------------
	 */

	/**
	 * Esta classe testa os elementos presentes na placa A3 - Pictograma e Buzzers -
	 * Sensores e Solenoides, é preciso testar os sensores manualmente quando
	 * solicitado
	 * 
	 * @throws Exception sensor
	 */
	public void testaPlaca() throws Exception {

		testaPlacaPrivate();
		sequenciaDeEncerramentoGpios();
	}

	/**
	 * Comportamento padrão Bloqueia entradas não autorizadas de acordo com o
	 * definido no int/enum comportamento Para alterar, usar a classe
	 * setComportamento, com o parâmetro enum direção
	 * 
	 * @throws Exception
	 */
	public void standard() throws Exception {

		switch (comportamento) {

		/**
		 * Comportamento nenhum livre, Bloqueia entradas não autorizadas a esquerda e a
		 * direita
		 */
		case NENHUM_LIVRE:

			nenhumLivrePrivate();
			break;

		/**
		 * Comportamento direita livre, Bloqueia entradas não autorizadas a esquerda
		 */
		case DIREITA_LIVRE:

			direitaLivrePrivate();
			break;

		/**
		 * Comportamento esquerda livre Bloqueia entradas não autorizadas a direita
		 */
		case ESQUERDA_LIVRE:

			esquerdaLivrePrivate();
			break;

		}
		sequenciaDeEncerramentoGpios();
	}

	/**
	 * Comportamento ticket negado Da uma indicação sonora e visual de bloqueio e
	 * bloqueia o lado que a pessoa tentar passar
	 * 
	 * @throws Exception
	 */
	public void TicketNegado() throws Exception {

		ticketNegadoPrivate();
		sequenciaDeEncerramentoGpios();
	}

	/**
	 * Classe que retorna se o giro foi feito ou não caso a pessoa tente girar para
	 * o lado errado, ela terá 3 tentativas para acertar caso o giro seja feito
	 * retorna true caso durante os 6 segundos não tente girar, ou falhe nas 3
	 * tentativas, ele retorna false.
	 * 
	 * @return Giro
	 * @throws Exception
	 */
	public boolean Giro() throws Exception {

		boolean resultado = false;

		switch (giro) {

		// Giro Liberado para os dois lados
		case AMBOS:

			resultado = giroAmbosPrivate();
			sequenciaDeEncerramentoGpios();
			return resultado;

		// Giro Liberado para direita
		case DIREITA:

			resultado = giroDireitaPrivate();
			sequenciaDeEncerramentoGpios();
			return resultado;

		// Giro Liberado para esquerda
		case ESQUERDA:

			resultado = giroEsquerdaPrivate();
			sequenciaDeEncerramentoGpios();
			return resultado;

		default:
			sequenciaDeEncerramentoGpios();
			return resultado;
		}

	}

	/**
	 * Define um novo comportamento padrão de giro para a catraca
	 * 
	 * @param giro
	 */
	public void setGiro(Giro giro) {
		this.giro = giro;
	}

	/**
	 * Define um novo comportamento padrão de bloqueia para a catraca
	 * 
	 * @param direcao
	 */
	public void setComportamento(Comportamento comportamento) {
		this.comportamento = comportamento;
	}

	/**
	 * -------------------------------------------------------------------------
	 * MÉTODOS PRIVADOS
	 * -------------------------------------------------------------------------
	 */

	/**
	 * Desliga as gpios temporariamente
	 * 
	 * @throws Exception
	 */
	public void sequenciaDeEncerramentoGpios() throws Exception {
		solenoideDireita.setValue("0");
		solenoideEsquerda.setValue("0");
		pictoNegado.setValue("0");
		pictoEsquerda.setValue("0");
		pictoDireita.setValue("0");
		buzzer.setValue("0");
	}

	/**
	 * Define o comportamento inicial das portas que vamos usar
	 * 
	 * @throws Exception
	 */
	private void setarComportamentosIniciais() throws Exception {
		pictoEsquerda.setDirection("out");
		pictoEsquerda.setValue("0");
		pictoDireita.setDirection("out");
		pictoDireita.setValue("0");
		pictoNegado.setDirection("out");
		pictoNegado.setValue("0");

		buzzer.setDirection("out");
		buzzer.setValue("0");

		solenoideDireita.setDirection("out");
		solenoideDireita.setValue("0");
		solenoideEsquerda.setDirection("out");
		solenoideEsquerda.setValue("0");

		sensorEsquerda.setDirection("in");
		sensorDireita.setDirection("in");
	}

	/**
	 * Testa os componentes da placa
	 * 
	 * @throws Exception
	 */
	private void testaPlacaPrivate() throws Exception {
		int sensor = 0;
		int sleepMs = 100;
		int sleepMs2 = 200;
		int sleepS = 1;

		System.out.println("Testando pictograma e buzzer!");

		for (int i = 0; i < 3; i++) {

			pictoEsquerda.setValue("0");
			pictoNegado.setValue("0");
			pictoDireita.setValue("1");
			buzzer.setValue("0");

			TimeUnit.MILLISECONDS.sleep(sleepMs);

			pictoEsquerda.setValue("0");
			pictoNegado.setValue("1");
			pictoDireita.setValue("0");
			buzzer.setValue("1");

			TimeUnit.MILLISECONDS.sleep(sleepMs);

			pictoEsquerda.setValue("1");
			pictoNegado.setValue("0");
			pictoDireita.setValue("0");
			buzzer.setValue("0");

			TimeUnit.MILLISECONDS.sleep(sleepMs);

			pictoEsquerda.setValue("0");
			pictoNegado.setValue("1");
			pictoDireita.setValue("0");
			buzzer.setValue("1");

			TimeUnit.MILLISECONDS.sleep(sleepMs);
		}

		pictoEsquerda.setValue("0");
		pictoNegado.setValue("0");
		pictoDireita.setValue("0");
		buzzer.setValue("0");

		TimeUnit.SECONDS.sleep(sleepS);

		// Testando solenoide Direita

		for (int i = 0; i < 2; i++) {
			TimeUnit.MILLISECONDS.sleep(sleepMs2);
			solenoideDireita.setValue("1");
			pictoNegado.setValue("1");
			TimeUnit.MILLISECONDS.sleep(sleepMs2);
			solenoideDireita.setValue("0");
			pictoNegado.setValue("0");
		}

		// Testando solenoide Esquerda

		for (int i = 0; i < 2; i++) {
			TimeUnit.MILLISECONDS.sleep(sleepMs2);
			solenoideEsquerda.setValue("1");
			pictoNegado.setValue("1");
			TimeUnit.MILLISECONDS.sleep(sleepMs2);
			solenoideEsquerda.setValue("0");
			pictoNegado.setValue("0");
		}

		/**
		 * Para testar o funcionamento dos sensores estou usando como parâmetro os
		 * valores da variável sensor:
		 */

		System.out.println("Teste o Sensor da Esquerda!");
		pictoEsquerda.setValue("1");
		pictoDireita.setValue("0");

		while (sensor == 0) {

			TimeUnit.MILLISECONDS.sleep(sleepMs);
			buzzer.setValue("1");
			TimeUnit.MILLISECONDS.sleep(sleepMs);
			buzzer.setValue("0");

			if (sensorEsquerda.getValue()) {
				pictoEsquerda.setValue("0");
				sensor = 1;
			}
		}

		System.out.println("Sensor esquerda funcional");

		System.out.println("Teste o Sensor da Direita!");
		pictoEsquerda.setValue("0");
		pictoDireita.setValue("1");

		while (sensor == 1) {

			TimeUnit.MILLISECONDS.sleep(sleepMs);
			buzzer.setValue("1");
			TimeUnit.MILLISECONDS.sleep(sleepMs);
			buzzer.setValue("0");

			if (sensorDireita.getValue()) {
				pictoDireita.setValue("0");
				sensor = 0;
			}

		}
		System.out.println("Sensor direita funcional");
	}

	/**
	 * Comportamento NenhumLivre, Bloqueia entradas não autorizadas a esquerda e a
	 * direita
	 * 
	 * @throws Exception
	 */
	private void nenhumLivrePrivate() throws Exception {

		int sleepS = 1;
		int sleepMsStandard = 300;

		while (sensorDireita.getValue() == sensorEsquerda.getValue()) {
			pictoDireita.setValue("1");
			pictoNegado.setValue("0");
			pictoEsquerda.setValue("1");
			TimeUnit.SECONDS.sleep(sleepS);
			pictoDireita.setValue("0");
			pictoNegado.setValue("1");
			pictoEsquerda.setValue("0");
			TimeUnit.SECONDS.sleep(sleepS);
		}

		sequenciaDeEncerramentoGpios();

		// Sequência de trancamento esquerda
		if (sensorDireita.getValue()) {
			solenoideEsquerda.setValue("1");
			for (int i = 0; i < 3; i++) {
				pictoNegado.setValue("1");
				pictoEsquerda.setValue("1");
				buzzer.setValue("1");
				TimeUnit.MILLISECONDS.sleep(sleepMsStandard);
				pictoNegado.setValue("0");
				pictoEsquerda.setValue("0");
				buzzer.setValue("0");
			}
			while (sensorEsquerda.getValue() || sensorDireita.getValue()) {
				pictoNegado.setValue("1");
				buzzer.setValue("1");
			}

			// Sequência de trancamento direita
		} else if (sensorEsquerda.getValue()) {
			solenoideDireita.setValue("1");
			for (int i = 0; i < 3; i++) {
				pictoNegado.setValue("1");
				pictoDireita.setValue("1");
				buzzer.setValue("1");
				TimeUnit.MILLISECONDS.sleep(sleepMsStandard);
				pictoNegado.setValue("0");
				pictoDireita.setValue("0");
				buzzer.setValue("0");
			}
			while (sensorEsquerda.getValue() || sensorDireita.getValue()) {
				pictoNegado.setValue("1");
				buzzer.setValue("1");
			}

		}
		TimeUnit.SECONDS.sleep(sleepS);
		sequenciaDeEncerramentoGpios();

	}

	/**
	 * Comportamento DireitaLivre, Bloqueia entradas não autorizadas a esquerda e
	 * libera a direita
	 * 
	 * @throws Exception
	 */
	private void direitaLivrePrivate() throws Exception {
		int sleepS = 1;
		int sleepMsStandard = 300;
		int sleepSStandard = 2;

		// Sequência de espera
		while (sensorDireita.getValue() == sensorEsquerda.getValue()) {
			pictoDireita.setValue("1");
			pictoNegado.setValue("0");
			pictoEsquerda.setValue("1");
			TimeUnit.SECONDS.sleep(sleepS);
			pictoDireita.setValue("0");
			pictoNegado.setValue("1");
			pictoEsquerda.setValue("0");
			TimeUnit.SECONDS.sleep(sleepS);
		}

		sequenciaDeEncerramentoGpios();

		// Sequência de trancamento, direita livre
		if (sensorDireita.getValue()) {
			solenoideEsquerda.setValue("1");
			for (int i = 0; i < 3; i++) {
				pictoNegado.setValue("1");
				pictoEsquerda.setValue("1");
				buzzer.setValue("1");
				TimeUnit.MILLISECONDS.sleep(sleepMsStandard);
				pictoNegado.setValue("0");
				pictoEsquerda.setValue("0");
				buzzer.setValue("0");
			}
			while (sensorEsquerda.getValue() || sensorDireita.getValue()) {
				pictoNegado.setValue("1");
				buzzer.setValue("1");
			}

			TimeUnit.SECONDS.sleep(sleepS);
			sequenciaDeEncerramentoGpios();

		} else if (sensorEsquerda.getValue()) {

			pictoDireita.setValue("1");
			buzzer.setValue("1");

			// 2 seg
			TimeUnit.SECONDS.sleep(sleepSStandard);

			while (sensorEsquerda.getValue() || sensorDireita.getValue()) {
				pictoDireita.setValue("1");
				buzzer.setValue("1");
			}
			sequenciaDeEncerramentoGpios();
		}
	}

	/**
	 * Comportamento EsquerdaLivre, Bloqueia entradas não autorizadas a direita e
	 * libera a esquerda
	 * 
	 * @throws Exception
	 */
	private void esquerdaLivrePrivate() throws Exception {
		int sleepS = 1;
		int sleepMsStandard = 300;
		int sleepSStandard = 2;

		// Sequência de espera
		while (sensorDireita.getValue() == sensorEsquerda.getValue()) {
			pictoDireita.setValue("1");
			pictoNegado.setValue("0");
			pictoEsquerda.setValue("1");
			TimeUnit.SECONDS.sleep(sleepS);
			pictoDireita.setValue("0");
			pictoNegado.setValue("1");
			pictoEsquerda.setValue("0");
			TimeUnit.SECONDS.sleep(sleepS);
		}

		sequenciaDeEncerramentoGpios();

		// Sequência de trancamento
		if (sensorEsquerda.getValue()) {
			solenoideDireita.setValue("1");
			for (int i = 0; i < 3; i++) {
				pictoNegado.setValue("1");
				pictoDireita.setValue("1");
				buzzer.setValue("1");
				TimeUnit.MILLISECONDS.sleep(sleepMsStandard);
				pictoNegado.setValue("0");
				pictoDireita.setValue("0");
				buzzer.setValue("0");
			}
			while (sensorEsquerda.getValue() || sensorDireita.getValue()) {
				pictoNegado.setValue("1");
				buzzer.setValue("1");
			}

			TimeUnit.SECONDS.sleep(sleepS);

			sequenciaDeEncerramentoGpios();
		} else if (sensorDireita.getValue() == true) {

			pictoEsquerda.setValue("1");
			buzzer.setValue("1");
			TimeUnit.SECONDS.sleep(sleepSStandard);

			while (sensorEsquerda.getValue() || sensorDireita.getValue()) {
				pictoEsquerda.setValue("1");
				buzzer.setValue("1");
			}

			pictoEsquerda.setValue("0");
			buzzer.setValue("0");

		}

	}

	/**
	 * Comportamento ticket negado, Da uma indicação sonora e visual de bloqueio e
	 * bloqueia o lado que a pessoa tentar passar
	 * 
	 * @throws Exception
	 */
	private void ticketNegadoPrivate() throws Exception {

		int contadorBloqueio = 0;
		int sleepS = 1;
		int sleepMsStandard = 300;

		// Sequência de negação
		while ((sensorDireita.getValue() == sensorEsquerda.getValue()) && contadorBloqueio != 4) {
			pictoNegado.setValue("1");
			buzzer.setValue("1");
			TimeUnit.SECONDS.sleep(sleepMsStandard);
			pictoNegado.setValue("0");
			buzzer.setValue("0");
			TimeUnit.SECONDS.sleep(sleepMsStandard);

			contadorBloqueio++;
		}

		sequenciaDeEncerramentoGpios();

		// Sequência de trancamento
		if (sensorDireita.getValue()) {
			solenoideEsquerda.setValue("1");
			for (int i = 0; i < 3; i++) {
				pictoNegado.setValue("1");
				pictoEsquerda.setValue("1");
				buzzer.setValue("1");
				TimeUnit.MILLISECONDS.sleep(sleepMsStandard);
				pictoNegado.setValue("0");
				pictoEsquerda.setValue("0");
				buzzer.setValue("0");
			}
			while (sensorEsquerda.getValue() || sensorDireita.getValue()) {
				pictoNegado.setValue("1");
				buzzer.setValue("1");
			}
			TimeUnit.SECONDS.sleep(sleepS);
			
		} else if (sensorEsquerda.getValue()) {
			solenoideDireita.setValue("1");
			for (int i = 0; i < 3; i++) {
				pictoNegado.setValue("1");
				pictoDireita.setValue("1");
				buzzer.setValue("1");
				TimeUnit.MILLISECONDS.sleep(sleepMsStandard);
				pictoNegado.setValue("0");
				pictoDireita.setValue("0");
				buzzer.setValue("0");
			}
			while (sensorEsquerda.getValue() || sensorDireita.getValue()) {
				pictoNegado.setValue("1");
				buzzer.setValue("1");
			}

			TimeUnit.SECONDS.sleep(sleepS);

		}

	}

	/**
	 * Giro Liberado para os dois lados
	 * 
	 * @throws Exception
	 */
	private boolean giroAmbosPrivate() throws Exception {

		boolean resultado = false;
		boolean fim = false;

		int contadorPassagem = 0;
		int contadorEsquerda = 0;
		int contadorDireita = 0;
		int contadorLowEsquerda = 0;
		int contadorLowDireita = 0;
		int sensD = 0;
		int sensE = 0;
		int retrocesso = 0;
		int sleepS = 1;

		// Sequência de espera, 6 segundos
		while ((sensorDireita.getValue() == sensorEsquerda.getValue()) && contadorPassagem <= 2) {
			pictoDireita.setValue("1");
			pictoEsquerda.setValue("1");
			TimeUnit.SECONDS.sleep(sleepS);
			pictoDireita.setValue("0");
			pictoEsquerda.setValue("0");
			TimeUnit.SECONDS.sleep(sleepS);

			contadorPassagem++;
		}

		// limpar picto
		sequenciaDeEncerramentoGpios();

		// Sequência de liberação e contagem de giro
		// Primeiro identifica o lado do giro:

		// Sensor da direita primeiro, significa giro para a esquerda
		if (sensorDireita.getValue()) {

			// Sequência de liberação de giro para a Esquerda

			while (!fim) {

				// Esse início faz a leitura recorrente dos sensores
				if (sensorDireita.getValue()) {
					sensD = 1;
					if (contadorDireita == 0) {
						contadorDireita = 1;
					}
				} else {
					sensD = 0;
					if (contadorLowDireita == 0) {
						contadorLowDireita = 1;
					}
				}

				if (sensorEsquerda.getValue()) {
					sensE = 1;

					if (contadorEsquerda == 0) {
						contadorEsquerda = 1;
					}
				} else {
					sensE = 0;
				}

				// Verifica se ouve um giro para a esquerda

				// Caso volte após ativar o da direita, volta não completa, retorna false
				if (contadorEsquerda == 0 && sensD == 0 && contadorDireita == 1) {
					resultado = false;
					fim = true;
				}

				// caso ative o da esquerda mas volte
				if (sensD == 1 && sensE == 0 && contadorEsquerda == 1) {
					retrocesso = 1;
				}

				// caso a volta seja completa, retorna true
				if (sensD == 0 && sensE == 0 && contadorDireita == 1 && contadorEsquerda == 1
						&& contadorLowDireita == 1) {
					resultado = true;
					fim = true;
					// caso volte tudo, após ativar os dois, retorna false
				} else if (sensE == 0 && sensD == 0 && retrocesso == 1) {
					resultado = false;
					fim = true;
				}
			}
			// caso identifique o sensor da esquerda primeiro, significa que está
			// dando uma volta para a direita
		} else if (sensorEsquerda.getValue()) {

			// Sequência de liberação de giro para a direita

			while (!fim) {

				// Esse início faz a leitura recorrente dos sensores
				if (sensorDireita.getValue()) {
					sensD = 1;
					if (contadorDireita == 0) {
						contadorDireita = 1;
					}
				} else {
					sensD = 0;
				}

				if (sensorEsquerda.getValue()) {
					sensE = 1;

					if (contadorEsquerda == 0) {
						contadorEsquerda = 1;
					}
				} else {
					sensE = 0;
					if (contadorLowEsquerda == 0) {
						contadorLowEsquerda = 1;
					}
				}

				// Verifica se ouve um giro para a direita

				// Caso volte após ativar o da esquerda, volta não completa, retorna false
				if (contadorEsquerda == 1 && sensE == 0 && contadorDireita == 0) {
					resultado = false;
					fim = true;
				}

				// caso ative o da direita mas volte
				if (sensE == 1 && sensD == 0 && contadorDireita == 1) {
					retrocesso = 1;
				}

				// caso a volta seja completa, retorna true
				if (sensD == 0 && sensE == 0 && contadorDireita == 1 && contadorEsquerda == 1
						&& contadorLowEsquerda == 1) {
					resultado = true;
					fim = true;
					// caso volte tudo, após ativar os dois, retorna false
				} else if (sensE == 0 && sensD == 0 && retrocesso == 1) {
					resultado = false;
					fim = true;
				}
			}
		}
		return resultado;
	}

	/**
	 * Giro Liberado para a direita
	 * 
	 * @throws Exception
	 */
	private boolean giroDireitaPrivate() throws Exception {

		boolean resultado = false;
		boolean fim = false;

		int contadorPassagem = 0;
		int contadorEsquerda = 0;
		int contadorDireita = 0;
		int contadorLowEsquerda = 0;
		int sensD = 0;
		int sensE = 0;
		int retrocesso = 0;
		int sleepS = 1;
		int sleepMsStandard = 300;
		int fracasso = 0;

		// Laço para dar 3 tentativas
		while (!resultado && fracasso < 3) {

			// Sequência de espera, 6 segundos
			while ((sensorDireita.getValue() == sensorEsquerda.getValue()) && contadorPassagem < 2) {
				pictoDireita.setValue("1");
				pictoEsquerda.setValue("1");
				TimeUnit.SECONDS.sleep(sleepS);
				pictoDireita.setValue("0");
				pictoEsquerda.setValue("0");
				TimeUnit.SECONDS.sleep(sleepS);

				contadorPassagem++;
			}

			// limpar picto
			sequenciaDeEncerramentoGpios();

			// Sequência de liberação e contagem de giro
			// Primeiro identifica o lado do giro:

			// Sensor da direita primeiro, significa giro para a esquerda
			if (sensorDireita.getValue()) {

				// Sequência de trancamento giro para a Esquerda
				solenoideEsquerda.setValue("1");
				for (int i = 0; i < 3; i++) {
					pictoNegado.setValue("1");
					pictoEsquerda.setValue("1");
					buzzer.setValue("1");
					TimeUnit.MILLISECONDS.sleep(sleepMsStandard);
					pictoNegado.setValue("0");
					pictoEsquerda.setValue("0");
					buzzer.setValue("0");
				}
				while (sensorEsquerda.getValue() || sensorDireita.getValue()) {
					pictoNegado.setValue("1");
					buzzer.setValue("1");
				}

				TimeUnit.SECONDS.sleep(sleepS);

				resultado = false;

				// caso identifique o sensor da esquerda primeiro, significa que está
				// dando uma volta para a direita
			} else if (sensorEsquerda.getValue()) {

				// Sequência de liberação de giro para a direita

				while (!fim) {

					// Esse início faz a leitura recorrente dos sensores
					if (sensorDireita.getValue()) {
						sensD = 1;
						if (contadorDireita == 0) {
							contadorDireita = 1;
						}
					} else {
						sensD = 0;
					}

					if (sensorEsquerda.getValue()) {
						sensE = 1;

						if (contadorEsquerda == 0) {
							contadorEsquerda = 1;
						}
					} else {
						sensE = 0;
						if (contadorLowEsquerda == 0) {
							contadorLowEsquerda = 1;
						}
					}

					// Verifica se ouve um giro para a direita

					// Caso volte após ativar o da esquerda, volta não completa, retorna false
					if (contadorEsquerda == 1 && sensE == 0 && contadorDireita == 0) {
						resultado = false;
						fim = true;
					}

					// caso ative o da direita mas volte
					if (sensE == 1 && sensD == 0 && contadorDireita == 1) {
						retrocesso = 1;
					}

					// caso a volta seja completa, retorna true
					if (sensD == 0 && sensE == 0 && contadorDireita == 1 && contadorEsquerda == 1
							&& contadorLowEsquerda == 1) {
						resultado = true;
						fim = true;
						// caso volte tudo, após ativar os dois, retorna false
					} else if (sensE == 0 && sensD == 0 && retrocesso == 1) {
						resultado = false;
						fim = true;
					}
				}
			}

			fracasso++;
		}
		// Sequencia de encerramento
		sequenciaDeEncerramentoGpios();
		return resultado;
	}

	/**
	 * Giro Liberado para a esquerda
	 * 
	 * @throws Exception
	 */
	private boolean giroEsquerdaPrivate() throws Exception {

		boolean resultado = false;
		boolean fim = false;

		int contadorPassagem = 0;
		int contadorEsquerda = 0;
		int contadorDireita = 0;
		int contadorLowDireita = 0;
		int sensD = 0;
		int sensE = 0;
		int retrocesso = 0;
		int sleepS = 1;
		int sleepMsStandard = 300;
		int fracasso = 0;

		// Laço para dar 3 tentativas
		while (!resultado && fracasso < 3) {

			// Sequência de espera, 6 segundos
			while ((sensorDireita.getValue() == sensorEsquerda.getValue()) && contadorPassagem < 2) {
				pictoDireita.setValue("1");
				pictoEsquerda.setValue("1");
				TimeUnit.SECONDS.sleep(sleepS);
				pictoDireita.setValue("0");
				pictoEsquerda.setValue("0");
				TimeUnit.SECONDS.sleep(sleepS);

				contadorPassagem++;
			}

			// limpar picto
			sequenciaDeEncerramentoGpios();

			// Sequência de liberação e contagem de giro
			// Primeiro identifica o lado do giro:

			// Sensor da direita primeiro, significa giro para a esquerda
			if (sensorDireita.getValue()) {

				// Sequência de liberação de giro para a Esquerda

				while (!fim) {

					// Esse início faz a leitura recorrente dos sensores
					if (sensorDireita.getValue()) {
						sensD = 1;
						if (contadorDireita == 0) {
							contadorDireita = 1;
						}
					} else {
						sensD = 0;
						if (contadorLowDireita == 0) {
							contadorLowDireita = 1;
						}
					}

					if (sensorEsquerda.getValue()) {
						sensE = 1;

						if (contadorEsquerda == 0) {
							contadorEsquerda = 1;
						}
					} else {
						sensE = 0;
					}

					// Verifica se ouve um giro para a esquerda

					// Caso volte após ativar o da direita, volta não completa, retorna false
					if (contadorEsquerda == 0 && sensD == 0 && contadorDireita == 1) {
						resultado = false;
						fim = true;
					}

					// caso ative o da esquerda mas volte
					if (sensD == 1 && sensE == 0 && contadorEsquerda == 1) {
						retrocesso = 1;
					}

					// caso a volta seja completa, retorna true
					if (sensD == 0 && sensE == 0 && contadorDireita == 1 && contadorEsquerda == 1
							&& contadorLowDireita == 1) {
						resultado = true;
						fim = true;
						// caso volte tudo, após ativar os dois, retorna false
					} else if (sensE == 0 && sensD == 0 && retrocesso == 1) {
						resultado = false;
						fim = true;
					}
				}

				// caso identifique o sensor da esquerda primeiro, significa que está
				// dando uma volta para a direita
			} else if (sensorEsquerda.getValue()) {

				solenoideDireita.setValue("1");
				for (int i = 0; i < 3; i++) {
					pictoNegado.setValue("1");
					pictoDireita.setValue("1");
					buzzer.setValue("1");
					TimeUnit.MILLISECONDS.sleep(sleepMsStandard);
					pictoNegado.setValue("0");
					pictoDireita.setValue("0");
					buzzer.setValue("0");
				}
				while (sensorEsquerda.getValue() || sensorDireita.getValue()) {
					pictoNegado.setValue("1");
					buzzer.setValue("1");
				}

				TimeUnit.SECONDS.sleep(sleepS);
				resultado = false;
			}

			fracasso++;
		}
		// Sequencia de encerramento
		sequenciaDeEncerramentoGpios();
		return resultado;

	}
}
